/*
 * Developer: Barton Leader
 * Date: 10/19/2025
 * Creates a swiss bracket tournament
 */

import java.util.Collections;
import java.util.List;

public class Swiss implements Tournament {
    @Override
    public void generatePairings(List<String> players) {
        System.out.println("\n=== Swiss Tournament Pairings ===");
        Collections.shuffle(players);

        for (int i = 0; i < players.size(); i += 2) {
            if (i + 1 < players.size()) {
                System.out.println(players.get(i) + " vs " + players.get(i + 1));
            } else {
                System.out.println(players.get(i) + " gets a bye.");
            }
        }
    }
}
