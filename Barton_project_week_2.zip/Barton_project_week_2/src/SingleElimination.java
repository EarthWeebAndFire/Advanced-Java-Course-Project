/*
 * Developer: Barton Leader
 * Date: 10/19/2025
 * creates a single elimination tournament bracket
 */

import java.util.Collections;
import java.util.List;

public class SingleElimination implements Tournament {
    @Override
    public void generatePairings(List<String> players) {
        System.out.println("\n=== Single Elimination Tournament Pairings ===");
        Collections.shuffle(players);

        for (int i = 0; i < players.size(); i += 2) {
            if (i + 1 < players.size()) {
                System.out.println(players.get(i) + " vs " + players.get(i + 1));
            } else {
                System.out.println(players.get(i) + " advances automatically (bye).");
            }
        }
    }
}
