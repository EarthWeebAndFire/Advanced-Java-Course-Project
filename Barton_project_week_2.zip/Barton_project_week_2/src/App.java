/*
 * Developer: Barton Leader
 * Date: 10/19/2025
 * starting application for tournament bracket project
 */

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        // Instantiate the main application with project info
        NameCollector app = new NameCollector("Barton Leader", "Week 2 - Tournament Pairing", "Week 2");

        // Run the program (collect names + choose tournament)
        app.collectNames();
        
        Scanner scanner = new Scanner(System.in);
        Tournament tournament = null;
        int choice = 0;
        boolean validInput = false;

        // Keep asking the user until a valid choice (1–3) is entered
        while (!validInput) {
            System.out.println("\nPlease choose a tournament type:");
            System.out.println("1. Swiss");
            System.out.println("2. Single Elimination");
            System.out.println("3. Double Elimination");
            System.out.print("Enter your choice (1-3): ");

            // Validate numeric input
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // consume newline

                if (choice >= 1 && choice <= 3) {
                    validInput = true; // exit loop when input is valid
                } else {
                    System.out.println("Invalid choice! Please enter 1, 2, or 3.\n");
                }
            } else {
                System.out.println("Invalid input! Please enter a number between 1 and 3.\n");
                scanner.nextLine(); // clear invalid input
            }
        }

        // Create the appropriate Tournament instance — demonstrating polymorphism
        if (choice == 1) {
            tournament = new Swiss();
        } else if (choice == 2) {
            tournament = new SingleElimination();
        } else if (choice == 3) {
            tournament = new DoubleElimination();
        }

        // Generate and display pairings using the chosen tournament type
        if (tournament != null) {
            tournament.generatePairings(app.getUserData().getNames());
        }

        // Close scanner to prevent resource leak
        scanner.close();
    }
}