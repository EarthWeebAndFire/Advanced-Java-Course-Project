/*
 * Developer: Barton Leader
 * Date: 10/19/2025
 * Displays project info and instructions for user
 */

public class Display {
    private String developerName;
    private String projectTitle;
    private String projectWeek;

    public Display(String developerName, String projectTitle, String projectWeek) {
        this.developerName = developerName;
        this.projectTitle = projectTitle;
        this.projectWeek = projectWeek;
    }

    public void displayHeader() {
        System.out.println("==========================================");
        System.out.println("Project: " + projectTitle);
        System.out.println("Developer: " + developerName);
        System.out.println("Project Week: " + projectWeek);
        System.out.println("==========================================\n");
    }

    public String getDeveloperName() {
        return developerName;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public String getProjectWeek() {
        return projectWeek;
    }
}
