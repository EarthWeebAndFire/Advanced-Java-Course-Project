/*
 * Developer: Barton Leader
 * Date: 10/19/2025
 * collects user inputs and stores them
 */

import java.util.Scanner;

public class NameCollector extends Display {
    private UserData userData;

    public NameCollector(String developerName, String projectTitle, String projectWeek) {
        super(developerName, projectTitle, projectWeek);
        this.userData = new UserData();
    }

    public void collectNames() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Welcome! Please enter player names one by one.");
            System.out.println("When finished, type 'enter' to display all names.\n");

            while (true) {
                System.out.print("Enter a name (or 'enter' to finish): ");
                String input = scanner.nextLine().trim();

                if (input.equalsIgnoreCase("enter")) {
                    break;
                } else if (!input.isEmpty()) {
                    userData.addName(input);
                }
            }
        }

        userData.displayNames();
    }

    public void showAppInfo() {
        displayHeader();
    }

    public UserData getUserData() {
        return userData;
    }
}
