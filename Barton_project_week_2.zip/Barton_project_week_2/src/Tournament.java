/*
 * Developer: Barton Leader
 * Date: 10/19/2025
 * Defines the interface for all tournament types in program.
 */

import java.util.List;

public interface Tournament {
    void generatePairings(List<String> players);
}
