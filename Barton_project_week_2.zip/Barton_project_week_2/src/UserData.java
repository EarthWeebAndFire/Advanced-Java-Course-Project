/*
 * Developer: Barton Leader
 * Date: 10/19/2025
 *stores names of competitors
 */

import java.util.ArrayList;
import java.util.List;

public class UserData {
    private List<String> names;

    public UserData() {
        this.names = new ArrayList<>();
    }

    public void addName(String name) {
        names.add(name);
    }

    public List<String> getNames() {
        return names;
    }

    public void displayNames() {
        System.out.println("\nYou have entered the following names:");
        for (String name : names) {
            System.out.println("- " + name);
        }
    }
}
