/*Creates a while loop to collect user names and stores them */

import java.util.Scanner;

public class NameCollector extends Display {
    private UserData userData;

    public NameCollector(String developerName, String projectTitle, String projectWeek) {
        super(developerName, projectTitle, projectWeek);
        this.userData = new UserData();
    }

    public void collectNames() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Welcome! Please enter names one by one.");
            System.out.println("When you are finished, type 'enter' to display all names.\n");

            while (true) {
                System.out.print("Enter a name (or 'enter' to finish): ");
                String input = scanner.nextLine().trim();

                if (input.equalsIgnoreCase("enter")) {
                    break;
                } else if (!input.isEmpty()) {
                    userData.addName(input);
                }
            }
        }
        userData.displayNames();
    }

    public void showAppInfo() {
        displayHeader();
    }
}
