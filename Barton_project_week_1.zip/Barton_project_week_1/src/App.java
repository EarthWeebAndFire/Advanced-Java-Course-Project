/*Base class for the application, run the program from here*/

public class App {
    public static void main(String[] args) {
        NameCollector app = new NameCollector("Barton Leader", "Week 1 - Name Collector", "Week 1");

        app.showAppInfo();

        app.collectNames();
    }
}